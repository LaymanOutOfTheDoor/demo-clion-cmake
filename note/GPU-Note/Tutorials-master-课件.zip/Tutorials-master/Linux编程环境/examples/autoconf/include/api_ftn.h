
#ifndef API_FTN_H
#define API_FTN_H

#include <stdio.h>

#include "config.h"

#ifdef __cplusplus
extern "C" {
#endif

void sls_input_(double *x);

#ifdef __cplusplus
}
#endif

#endif
