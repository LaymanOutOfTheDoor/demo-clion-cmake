
#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>

#include "config.h"

#ifdef __cplusplus
extern "C" {
#endif

void sls_print(void);

#ifdef __cplusplus
}
#endif

#endif
