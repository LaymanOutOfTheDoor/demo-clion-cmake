
#include "utils.h"

void sls_print(void)
{
    printf("hello, world!\n");
}
