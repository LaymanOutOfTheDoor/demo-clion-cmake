
#include "add.h"

double sls_add(double x, double y)
{
    return x + y;
}
