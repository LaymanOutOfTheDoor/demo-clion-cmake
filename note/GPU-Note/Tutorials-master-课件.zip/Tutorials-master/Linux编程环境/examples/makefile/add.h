
#ifndef ADD_H
#define ADD_H

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

double sls_add(double x, double y);

#ifdef __cplusplus
}
#endif

#endif
