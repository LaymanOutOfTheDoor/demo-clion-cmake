
# MPI
Some basic examples to show how to use MPI.
