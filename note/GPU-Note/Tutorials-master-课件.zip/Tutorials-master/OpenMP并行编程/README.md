
# OpenMP Intro

Basic examples to show how to use OpenMP.

